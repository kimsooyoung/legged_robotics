# Copyright (c) 2020-2021, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.

import asyncio
import numpy as np
from omni.isaac.examples.base_sample import BaseSample
from omni.isaac.core.objects import DynamicCuboid
from omni.isaac.core.utils.types import ArticulationAction
from omni.isaac.core.utils.nucleus import get_assets_root_path
from omni.isaac.core.utils.stage import add_reference_to_stage
from omni.isaac.core.robots import Robot
import carb

import omni.appwindow  # Contains handle to keyboard
from omni.isaac.quadruped.robots import Unitree

# Note: checkout the required tutorials at https://docs.omniverse.nvidia.com/app_isaacsim/app_isaacsim/overview.html
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class Subscriber(Node):
    def __init__(self):
        super().__init__("twsit_subscriber")

        self.twist = Twist()
        # setting up the world with a cube
        self.twist_sub = self.create_subscription(
            Twist, 'cmd_vel', self.twist_callback, 10
        )

    def twist_callback(self, data):
        self.twist = data

    def get_twist(self):
        return self.twist


class HelloWorld(BaseSample):
    def __init__(self) -> None:
        super().__init__()
        
        rclpy.init()
        self.subscriber = Subscriber()

        self._world_settings["stage_units_in_meters"] = 1.0
        self._world_settings["physics_dt"] = 1.0 / 400.0
        self._world_settings["rendering_dt"] = 20.0 / 400.0
        self._enter_toggled = 0
        self._base_command = [0.0, 0.0, 0.0, 0] # x, y, yaw, TODO: 마지막은 뭐지? 
        self._event_flag = False

        return

    def setup_scene(self) -> None:
        world = self.get_world()
        self._world.scene.add_default_ground_plane(
            z_position=0,
            name="default_ground_plane",
            prim_path="/World/defaultGroundPlane",
            static_friction=0.2,
            dynamic_friction=0.2,
            restitution=0.01,
        )
        self._go1 = world.scene.add(
            Unitree(
                prim_path="/World/Go1", 
                name="Go1", 
                position=np.array([0, 0, 0.400]), 
                physics_dt=self._world_settings["physics_dt"], 
                # model="Go1Velo"
                model="Go1Pure"
            )
        )
        return
    
    async def setup_post_load(self) -> None:
        self._world = self.get_world()
        self._appwindow = omni.appwindow.get_default_app_window()
        self._input = carb.input.acquire_input_interface()
        self._world.add_physics_callback("sending_actions", callback_fn=self.on_physics_step)
        await self._world.play_async()
        return

    async def setup_pre_reset(self) -> None:
        self._event_flag = False
        return

    async def setup_post_reset(self) -> None:
        await self._world.play_async()
        self._go1.check_dc_interface()
        self._go1.set_state(self._go1._default_a1_state)
        return

    def on_physics_step(self, step_size) -> None:
        if self._event_flag:
            self._go1._qp_controller.switch_mode()
            self._event_flag = False
        
        rclpy.spin_once(self.subscriber, timeout_sec=0.0)
        twist = self.subscriber.get_twist()
        self._base_command[0] = twist.linear.x
        self._base_command[1] = twist.linear.y
        self._base_command[2] = twist.angular.z

        print(self._base_command)

        # self._go1.advance(step_size, self._base_command)
        self._go1.advance(step_size, self._base_command, auto_start=False)

    def _menu_callback(self):
        super()._menu_callback()
        self._on_environment_setup()
        return

    def _on_environment_setup(self):

        self._assets_root_path = get_assets_root_path()
        if self._assets_root_path is None:
            carb.log_error("Could not find Isaac Sim assets folder")
            return

        asyncio.ensure_future(self._create_moveit_sample())

    async def _create_moveit_sample(self):
        await omni.kit.app.get_app().next_update_async()
        self.create_ros_action_graph("/World/Go1")
        await omni.kit.app.get_app().next_update_async()

    def create_ros_action_graph(self, franka_stage_path):
        pass
